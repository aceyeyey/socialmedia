import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-panel',
  templateUrl: './tab-panel.component.html',
  styleUrls: ['./tab-panel.component-main.scss']
})
export class TabPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
